/* ==========================================================
   GrowTrans Solutions – site settings
   Edit ONLY this file to add your real contact details.
   Leave a value as "" (empty) until you have the real one –
   the website will then show a clearly marked placeholder
   instead of a fake link.
   ========================================================== */
window.GROWTRANS_CONFIG = {
  // Your confirmed business email, e.g. "hr@yourdomain.com"
  email: "",

  // Your LinkedIn company page URL, e.g. "https://www.linkedin.com/company/your-page"
  linkedin: "",

  // Optional: leave "" unless you want to show a phone number
  phone: "",

  // Maximum resume size in MB. Netlify's form request limit is about 8 MB,
  // so keep this at 5 or lower.
  maxResumeMB: 5
};
