/* ==========================================================
   GrowTrans Solutions – site behaviour
   1. Mobile menu   2. Contact placeholders   3. Scroll reveal
   4. Form submission (Netlify Forms) with clear success/error
   ========================================================== */
(function () {
  "use strict";

  var cfg = window.GROWTRANS_CONFIG || {};

  /* ---------- 1. Mobile navigation ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var menu = document.getElementById("nav-menu");
  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      var open = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    menu.addEventListener("click", function (e) {
      if (e.target.closest("a")) {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && menu.classList.contains("open")) {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  /* ---------- 2. Contact details from config.js ---------- */
  document.querySelectorAll("[data-email]").forEach(function (el) {
    if (cfg.email) {
      var a = document.createElement("a");
      a.href = "mailto:" + cfg.email;
      a.textContent = cfg.email;
      el.replaceChildren(a);
    }
  });
  document.querySelectorAll("[data-linkedin]").forEach(function (el) {
    if (cfg.linkedin) {
      var a = document.createElement("a");
      a.href = cfg.linkedin;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = el.getAttribute("data-linkedin") || "LinkedIn";
      el.replaceChildren(a);
    }
  });
  document.querySelectorAll("[data-phone]").forEach(function (el) {
    var row = el.closest("li") || el;
    if (cfg.phone) {
      var a = document.createElement("a");
      a.href = "tel:" + cfg.phone.replace(/[^+\d]/g, "");
      a.textContent = cfg.phone;
      el.replaceChildren(a);
      row.hidden = false;
    }
  });

  /* ---------- 3. Scroll reveal ---------- */
  var items = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("in");
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach(function (el) { io.observe(el); });
  } else {
    items.forEach(function (el) { el.classList.add("in"); });
  }

  /* ---------- 4. Forms ---------- */
  var MAX_MB = Number(cfg.maxResumeMB) || 5;

  function fallbackText() {
    return cfg.email
      ? "Please try again, or email us directly at " + cfg.email + "."
      : "Please try again in a few minutes, or contact us through the other details on this site.";
  }

  function showStatus(box, type, msg) {
    box.textContent = msg;
    box.className = "form-status show " + type;
    box.focus();
  }

  document.querySelectorAll("form[data-gt-form]").forEach(function (form) {
    var box = form.querySelector(".form-status");
    var btn = form.querySelector('button[type="submit"]');
    var btnLabel = btn ? btn.textContent : "";

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      box.className = "form-status";

      // Honeypot: real people never fill this in
      var hp = form.querySelector('input[name="bot-field"]');
      if (hp && hp.value) { return; }

      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      // Resume file checks
      var file = form.querySelector('input[type="file"]');
      if (file && file.files && file.files[0]) {
        var f = file.files[0];
        var okType = /\.(pdf|doc|docx)$/i.test(f.name);
        if (!okType) {
          showStatus(box, "err", "Please upload your resume as a PDF, DOC or DOCX file.");
          return;
        }
        if (f.size > MAX_MB * 1024 * 1024) {
          showStatus(box, "err", "Your file is larger than " + MAX_MB + " MB. Please upload a smaller file" +
            (cfg.email ? " or email it to " + cfg.email + "." : "."));
          return;
        }
      }

      btn.disabled = true;
      btn.textContent = "Sending…";

      // Netlify Forms accepts a normal multipart POST to the site root
      // when the body includes the hidden "form-name" field.
      fetch("/", { method: "POST", body: new FormData(form) })
        .then(function (res) {
          if (!res.ok) { throw new Error("HTTP " + res.status); }
          form.reset();
          showStatus(box, "ok", form.getAttribute("data-success") ||
            "Thank you! Your message has been sent. We will get back to you soon.");
        })
        .catch(function () {
          showStatus(box, "err", "Sorry, we could not send your form. " + fallbackText());
        })
        .finally(function () {
          btn.disabled = false;
          btn.textContent = btnLabel;
        });
    });
  });
})();
